﻿
using Microsoft.EntityFrameworkCore;
using Teste.Models;
namespace Teste.Models
{
    public class BancoContext :  DbContext
    {
        public DbSet<Usuario> Usuario { get; set; }
       /* public DbSet<Ong> Ong { get; set; }
        public DbSet<Doacao> Doacao { get; set; }
        public DbSet<Adocao> Adocao { get; set; }*/
        


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=SNCCH01LABF120\TEW_SQLEXPRESS;Database=OHANA;Trusted_Connection=True;");
        }
    }
}
