﻿namespace Teste.Models
{
    public class Adocao
    {
        public int Id_adocao { get; set; }
        public string Porte { get; set; }
        public float Peso { get; set; }
        public string Raca { get; set; }
        public int Id_usuario { get; set; }
        public int Id_ong { get; set; }




    }

}
