﻿using System.ComponentModel.DataAnnotations;

namespace Teste.Models
{
    public class Usuario
    {
        [Key]
        public int id_usuario { get; set; }
        public string Nome_usuario { get; set; }
        public string Sobrenome_usuario { get; set; }
        public string Login_usuario { get; set; }
        public string Senha_usuario { get; set; }
        public string Cpf_usuario { get; set; }
        public string Email { get; set; }
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Complemento { get; set; }

    }
}
