﻿namespace Teste.Models
{
    public class Doacao
    {
        public int Id_doacao{ get; set; }
        public string tipo_doacao { get; set; }
        public DateTime Data_doacao { get; set; }
        public int Id_usuario { get; set; }
        public int Id_ong { get; set; }
    }
}
