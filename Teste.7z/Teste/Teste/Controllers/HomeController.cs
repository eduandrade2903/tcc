﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Teste.Models;

namespace Teste.Controllers
{
    public class HomeController : Controller
    {
        private readonly BancoContext _context;

        public HomeController(BancoContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult IndexLogado()
        {
            return View();
        }
        public IActionResult Pagina1()
        {
            return View();
        }

        public IActionResult Contato()
        {
            return View();
        }

        public IActionResult Cadastro()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        /*public IActionResult validaLogin(Usuario usuario) //funcionando
        {
            
            Usuario Login = new Usuario();
            Usuario nome = usuario;

            Login = _context.Usuario.FirstOrDefault(a => a.Login_usuario == usuario.Login_usuario);
           
            if (Login != null)
            {
                return View("IndexLogado");
            }
            else
            {
                return View ("Error");
             }

            
        }*/
        public IActionResult SalvarUsuario(Usuario usuario)
        {
            Usuario usuarioEncontrado = new Usuario();
            

            usuarioEncontrado = _context.Usuario.FirstOrDefault(a => a.id_usuario == usuario.id_usuario);

            //nomeDeUsuario = _context.Usuario.FirstOrDefault(a => a.Nome_usuario == usuario.Nome_usuario);


            if(usuarioEncontrado == null )
            {
                
                if (validaNomeUsuario(usuario) == false)
                {
                    _context.Usuario.Add(usuario);
                    _context.SaveChanges();
                }
                
                return View("IndexLogado");
            }
            else
            {
                return View("UsuarioExistente");
            }



            return View("IndexLogado");
        }
        public bool validaNomeUsuario(Usuario usuario)
        {
            Usuario nome = new Usuario();

            nome =  _context.Usuario.FirstOrDefault(a => a.Login_usuario == usuario.Login_usuario);
           
            if(nome != nome)
            {
                return true;
            }

            return false;
            
        }

            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
            IActionResult Error()
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }
    }
