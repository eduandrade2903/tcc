﻿/*using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Teste.Models;

namespace Teste.Controllers
{
    public class OngController : Controller
    {
        private readonly BancoContext _context;

        public OngController(BancoContext context)
        {
            _context = context;
        }

        public IActionResult LoginOng(Ong ong)
        {
            Ong ongFind =  new Ong();
            Ong ongPass =  new Ong();   
            ongFind = _context.Ong.FirstOrDefault(a => a.Login_ong == ong.Login_ong);
            ongPass = _context.Ong.FirstOrDefault(a => a.getSenha == ong.getSenha);

            if (ongFind == ongFind)
            {
                return View("PerfilOng");
            }

            return View();
        }
    }
}*/
