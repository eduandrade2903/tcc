﻿namespace TESTE.Models
{
    public class Ong
    {
        public int Id_ong { get; set; }
        public string Nome_ong { get; set; }
        public string Login_ong { get; set; }
        public string Senha_ong { get; set; }
        public int Id_endereco { get; set; }
    }
}
