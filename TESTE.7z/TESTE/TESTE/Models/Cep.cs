﻿namespace TESTE.Models
{
    public class Cep
    {
        public int Id_cep { get; set; }
        public string Nome_rua { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
    }
}
