﻿namespace TESTE.Models
{
    public class Doacao
    {
        public int Id_doacao { get; set; }
        public string Tipo_doacao { get; set; }
        public DateTime Data_doacao { get; set; }
        public int Id_user { get; set; }
        public int Id_ong { get; set; }
    }
}
