﻿using Microsoft.EntityFrameworkCore;
using TESTE.Models;


namespace TESTE.Models
{
    public class BancoContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Ong> Ongs { get; set; }
        public DbSet<Endereco> Enderecos { get; set; }
        public DbSet<Doacao> Doacoes { get; set; }
        public DbSet<Cep> Ceps { get; set; }
        public DbSet<Adocao> Adocoes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=SNCCH01LABF120\SQLEXPRESS;Database=Pagamento;Trusted_Connection=True;");
        }


    }
}
