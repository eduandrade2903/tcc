﻿namespace TESTE.Models
{
    public class Adocao
    {
        public int Id_adocao { get; set; }
        public string Porte { get; set; }
        public string Peso { get; set; }
        public string Raca { get; set; }
        public int  Id_ong { get; set; }
        public int Id_user { get; set; }
    }
}
