﻿namespace TESTE.Models
{
    public class Endereco
    {
        public int Id_end { get; set; }
        public string tua { get; set; }
        public int numero{ get; set; }
        public int Id_cep { get; set; }
      
    }
}
