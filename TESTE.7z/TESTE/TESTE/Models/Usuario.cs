﻿namespace TESTE.Models
{
    public class Usuario
    {
        public int Id_user { get; set; }
        public string Nome_user { get; set; }
        public string Sobrenome_user { get; set; }
        public string Login_user { get; set; }
        public string Senha_user { get; set; }
        public int Id_endereco { get; set; }
    }
}
